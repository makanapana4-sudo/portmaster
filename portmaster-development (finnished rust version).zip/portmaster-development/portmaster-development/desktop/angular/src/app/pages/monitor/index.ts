export { MonitorPageComponent } from './monitor';
