param(
    [string]$Name = "example.com",
    [int]$Count = 20,
    [string]$OutCsv = "..\baseline\dns-latency.csv"
)

# Measures DNS resolution latency via Resolve-DnsName under current system resolver config.
# Run under identical conditions for baseline and candidate; ensure Portmaster/config state is documented.

$rows = @()
for ($i = 1; $i -le $Count; $i++) {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    try {
        $r = Resolve-DnsName -Name $Name -ErrorAction Stop
        $sw.Stop()
        $rows += [pscustomobject]@{ Index=$i; Name=$Name; Success=$true; Ms=[math]::Round($sw.Elapsed.TotalMilliseconds,3); Answers=@($r).Count }
    } catch {
        $sw.Stop()
        $rows += [pscustomobject]@{ Index=$i; Name=$Name; Success=$false; Ms=[math]::Round($sw.Elapsed.TotalMilliseconds,3); Answers=0 }
    }
    Start-Sleep -Milliseconds 200
}
$dir = Split-Path -Parent $OutCsv
if ($dir -and !(Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
$rows | Export-Csv -NoTypeInformation -Path $OutCsv -Encoding UTF8
$ok = $rows | Where-Object { $_.Success }
if ($ok.Count -gt 0) {
    $sorted = $ok.Ms | Sort-Object
    $median = $sorted[[math]::Floor(($sorted.Count-1)/2)]
    Write-Host "Median(ms): $median  Min: $(($ok.Ms|Measure-Object -Minimum).Minimum)  Max: $(($ok.Ms|Measure-Object -Maximum).Maximum)"
}
Write-Host "Wrote $OutCsv"
