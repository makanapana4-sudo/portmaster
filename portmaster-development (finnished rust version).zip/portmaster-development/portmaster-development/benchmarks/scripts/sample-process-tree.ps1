param(
    [Parameter(Mandatory=$true)][string]$NamePattern,
    [int]$DurationSeconds = 300,
    [int]$IntervalSeconds = 5,
    [string]$OutCsv = "..\rust-final\process-samples.csv"
)

# Samples CPU/RAM/IO/threads for processes matching NamePattern (best-effort).
# Does not install drivers/services or modify system settings.

$ErrorActionPreference = 'Continue'
$start = Get-Date
$end = $start.AddSeconds($DurationSeconds)
$rows = @()

while ((Get-Date) -lt $end) {
    $ts = (Get-Date).ToString('o')
    $procs = Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like $NamePattern -or $_.Path -like "*${NamePattern}*" }
    foreach ($p in $procs) {
        try {
            $rows += [pscustomobject]@{
                Timestamp = $ts
                Name = $p.ProcessName
                Id = $p.Id
                WorkingSet = $p.WorkingSet64
                PrivateMemory = $p.PrivateMemorySize64
                CPUSeconds = $p.CPU
                Threads = $p.Threads.Count
                Handles = $p.HandleCount
                Path = $p.Path
            }
        } catch {}
    }
    Start-Sleep -Seconds $IntervalSeconds
}

$dir = Split-Path -Parent $OutCsv
if ($dir -and !(Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
$rows | Export-Csv -NoTypeInformation -Path $OutCsv -Encoding UTF8
Write-Host "Wrote $($rows.Count) samples to $OutCsv"
