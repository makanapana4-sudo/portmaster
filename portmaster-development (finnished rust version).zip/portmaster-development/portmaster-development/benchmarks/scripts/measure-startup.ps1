param(
    [Parameter(Mandatory=$true)][string]$ExePath,
    [string[]]$Arguments = @(),
    [int]$Runs = 5,
    [int]$ReadyTimeoutSeconds = 120,
    [string]$OutJson = "..\baseline\startup.json"
)

# Basic cold/warm process-launch timing helper (process creation only by default).
# Extend with UI-ready / core-ready / protection-active markers for the specific build.
# Does not install drivers/services or modify system settings.

$ErrorActionPreference = 'Stop'
$results = @()

for ($i = 1; $i -le $Runs; $i++) {
    $sw = [System.Diagnostics.Stopwatch]::StartNew()
    $p = Start-Process -FilePath $ExePath -ArgumentList $Arguments -PassThru
    $startMs = $sw.Elapsed.TotalMilliseconds
    # Placeholder: without a known readiness probe, record process-start observation only.
    $results += [ordered]@{
        run = $i
        pid = $p.Id
        processStartedMs = [math]::Round($startMs, 3)
        note = "Process creation observed; UI/core/protection readiness markers require app-specific probes."
    }
    Start-Sleep -Seconds 2
    try { if (!$p.HasExited) { Stop-Process -Id $p.Id -Force -ErrorAction SilentlyContinue } } catch {}
    Start-Sleep -Seconds 2
}

$med = ($results | Measure-Object -Property processStartedMs -Minimum -Maximum).Minimum # placeholder
$payload = [ordered]@{
    exe = $ExePath
    runs = $Runs
    results = $results
    note = "Replace/extend with real readiness checks; report median/range over >=5 runs."
}
$dir = Split-Path -Parent $OutJson
if ($dir -and !(Test-Path $dir)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }
$payload | ConvertTo-Json -Depth 6 | Set-Content -Path $OutJson -Encoding UTF8
Write-Host "Wrote $OutJson"
