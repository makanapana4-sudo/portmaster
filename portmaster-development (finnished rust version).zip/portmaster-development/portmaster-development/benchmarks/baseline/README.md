# Baseline measurements (original Go-based Portmaster)

No baseline measurements were collected in this session.

Reasons:
- Required build toolchains/infrastructure were not fully available (Go/Earthly/Docker initially missing; Rust/Tauri/linker constraints also present).
- This workspace is not a Git repository with local history/worktrees to select and build an original revision in isolation.
- Running/benchmarking Portmaster meaningfully may require Administrator privileges and installation/activation of compatible signed services/drivers, which was not performed.

Place raw CSV/JSON/log outputs and environment metadata here when a valid baseline is captured on the target PC.
