# Benchmarks (Portmaster: Go baseline vs Rust-powered)

This document describes how to reproduce baseline and candidate measurements on a Windows x64 machine. **No benchmark numbers in this repository run were fabricated.** In this session, baseline and Rust-final measurements were **not collected** because (1) required build toolchains were unavailable (`go`, `cargo/rustc`, `earthly`, `docker`) so neither the original nor a Rust-powered Portmaster could be built here, and (2) running Portmaster for meaningful measurements may require Administrator privileges, service/driver installation, and compatible signed driver artifacts—actions that must not be performed automatically.

## Benchmark targets
- **Baseline (original Go-based Portmaster):** build from an appropriate original/upstream revision in a separate Git worktree or temporary copy (do not reset/overwrite the current working directory).
- **Candidate (Rust-powered Portmaster):** build from this repository after real Rust integration into the production execution path (not just `rust-core` libraries).

## Hardware / environment (primary target as specified)
- CPU: AMD Ryzen 5 5600G
- GPU: NVIDIA GeForce GTX 1660 Super
- RAM: 16 GB DDR4 (1×16 GB)
- OS: Windows 10/11

Record the exact Windows build, power plan, background load, Portmaster revision/commit (or source snapshot), configuration/profile, and whether WebView2/driver/service components were installed.

## Metrics to collect
### Startup
- Time to process creation (EXE launch observed)
- Time until desktop UI is usable (window responsive / main UI loaded)
- Time until core service is ready (API/health endpoint responsive, per app contract)
- Time until network protection is active (driver/interception verdict path active — only claim if actually verified)
- Cold-process startup and repeated warm-process startup
- **At least 5 runs** per scenario; report **median** and range (ms and s)

### CPU
- Average CPU while idle
- Peak CPU during startup
- Average CPU during normal browsing
- CPU during DNS activity
- CPU during heavier network activity
- Measure **complete process tree** (UI, core/service, helpers)

### RAM
- Initial, after 1 min, 5 min, 15 min, and long-running
- Record **Working Set** and **Private Bytes / Private Working Set** where available
- Check for continuous growth over time (leak indicator)

### GPU
- Average/peak GPU utilization and engine usage
- Dedicated and shared GPU memory
- Separate UI vs core/service where counters allow; report **N/A** if per-process GPU metrics are unavailable/reliable on the system

### Other
- Executable size(s), total runtime/install footprint
- Disk read/write activity
- DNS lookup latency (controlled queries/resolver conditions)
- Connection processing overhead (if measurable safely)
- Idle background thread count
- Responsiveness observations (scripted or documented manual checks)

## Tools / approach (Windows)
- **PowerShell** process sampling: `Get-Process`, `Get-Counter` (e.g. `\Process(*)\% Processor Time`, `\Process(*)\Working Set - Private`, `\Process(*)\Private Bytes`, `\Process(*)\IO Read Bytes/sec`, `\Process(*)\IO Write Bytes/sec`, `\Process(*)\Thread Count`)
- **GPU:** `Get-Counter '\GPU Engine(*)\Utilization Percentage'`, `\GPU Adapter Memory(*)\Dedicated Usage`, `\GPU Adapter Memory(*)\Shared Usage` (availability varies; map instances to processes where possible) or `nvidia-smi` if installed
- **ETW/WPA** or **Windows Performance Recorder** for deeper traces (optional, manual)
- **DNS latency:** `Resolve-DnsName` / controlled `nslookup` loops or app-instrumented timings under identical resolver/config conditions
- Existing sampler: `rust-core/tools/measure-process.ps1` (process-level Working Set/Private/CPU samples) — useful once processes exist

## Repeatable scripts
Store scripts under `benchmarks/scripts/` and raw outputs under `benchmarks/baseline/` and `benchmarks/rust-final/`.

Suggested scripts (templates to be completed for the actual binary names/paths/service model):
- `benchmarks/scripts/measure-startup.ps1` — launch N times, record timestamps/markers, compute median/range
- `benchmarks/scripts/sample-process-tree.ps1` — periodic sampling of CPU/RAM/IO/threads for a process set over a duration
- `benchmarks/scripts/measure-dns.ps1` — repeated DNS queries with timing statistics
- `benchmarks/scripts/collect-gpu.ps1` — GPU counters snapshot/sampling (best-effort)

> Scripts must not disable Windows Defender/Firewall, must not install drivers/services, and must not modify system networking configuration.

## Comparison & reporting
- Save raw CSV/JSON/log outputs per run in `benchmarks/baseline/` and `benchmarks/rust-final/`.
- Compute `Improvement = ((Original - Rust) / Original) × 100` for lower-is-better metrics; invert appropriately for higher-is-better metrics (e.g. throughput).
- Report regressions explicitly.
- Document any feature still running through Go in the Rust-powered build.

## Current session status
- `benchmarks/baseline/`: no measurements (original build not produced/run here)
- `benchmarks/rust-final/`: no measurements (Rust-powered integrated build not produced/run here)
- Reason: missing toolchains/build artifacts and safety constraints around installing/activating firewall/driver components.

See `PERFORMANCE_REPORT.md` for the (currently unavailable) comparison summary.
